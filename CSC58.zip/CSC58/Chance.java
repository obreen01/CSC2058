
public class Chance {

    // Holds details of all different types of Chance occurences
    private String[] chanceTypes = {"Add Resource", "Decrease Resource", "Add Money", "Decrease Money", "Move Tile"};
    private String chanceType;
    private double resourceAdjustment; // Can be negative or positive depending on chance
    private double moneyAdjustment;
    private int moveTile;

    public String getChanceType() {
        return chanceType;
    }

    public void setChanceType(String chanceType) {
        this.chanceType = chanceType;
    }

    public double getResourceAdjustment() {
        return resourceAdjustment;
    }

    public void setResourceAdjustment(double resourceAdjustment) {
        this.resourceAdjustment = resourceAdjustment;
    }

    public double getMoneyAdjustment() {
        return moneyAdjustment;
    }

    public void setMoneyAdjustment(double moneyAdjustment) {
        this.moneyAdjustment = moneyAdjustment;
    }

    public int getMoveTile() {
        return moveTile;
    }

    public void setMoveTile(int moveTile) {
        this.moveTile = moveTile;
    }
}
