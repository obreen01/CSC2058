//import java.Player;
//import java.Tile;

import java.util.Scanner;
public class Finance {
	
	private int playerFinance;
	static final int rateLevelMAX = 10;
	Scanner choice = new Scanner(System.in);

	//Method used to increase 'lease' or rate you have to pay the other player when land on their resource
	public static void increaseLease(Resource resource) {
		if (resource.getCurrentRate() < rateLevelMAX) {
			resource.setCurrentRate(resource.getCurrentRate() + 1);
		}
	}

	// buy method 
	public static void displayBuyMenu(Player resourceOwner, Tile resource) {
		System.out.println("This Tile costs: " + resource.getPrice());
		System.out.println("1) Buy Tile");
		System.out.println("2) Return");
		System.out.println();

		Scanner input = new Scanner(System.in);
		int choice = input.nextInt();
		processBuyChoice(choice, resourceOwner, resource);
	}
	public static void processBuyChoice(int choice,Player resourceOwner, Tile resource) {
	switch (choice) {
	case 1:
		BuyLand(resourceOwner, resource);
		break;

	case 2:
		return;

	default:
		System.out.println("Invalid choice");
		}
	}
	public static void BuyLand(Player resourceOwner, Tile resource)  {
	if (resourceOwner.getMoney() >= resource.getPrice() && resource.getPlayerNo() != resource.getOwnerOfResource()) {	
		System.out.println("You have buy a new property " + resource.getTileName());
		}
	}
	//Check bankrupt- lose game
	public boolean isPlayerBankRupt(Player player, int finance, int totalValueOfResources) {
		totalValueOfResources = totalValueOfResources + player.getMoney();

		if (totalValueOfResources < playerFinance) {
			totalValueOfResources = 0;
			return true;
		}
		totalValueOfResources = 0;
		return false;
	}
}




