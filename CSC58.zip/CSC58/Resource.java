
public class Resource {
	
	//This class hold the resources the player can buy for their business

	static String[] hardware = {"Computers", "HardDrives", "Expansion Cards", "SSDs", "CPUs", "Optical Disc Drive"};
	static String[] software = {"Software IDE", "Open Source IDE", "Database IDE", "Accounting Software", "Payroll Software", "Project Management Software"};
	String[] servers = {"Client Server", "FTP Server", "Database Server", "Mail Server", "Open Source Server", "Proxy Server"};
	String[] premise = {"Start-up Office", "Small Office Building", "Office Skyscraper", "Server Farm", "International Offices Expansion"};
	String[] humanResources = {"Programmer Employee", "Small Programming Group", "Project Manager", "Software Architect", "CTO"};
	private String resourceName;
	private int currentRate;
	private int price;

	public String getResourceName() {
		return resourceName;
	}

	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}

	public void setCurrentRate(int currentRate) {
		this.currentRate = currentRate;
	}

	public int getCurrentRate() {
		return currentRate;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public static void getResourceField()
	{
		String[] resources = {"Software", "Hardware", "Servers", "Premise", "Human Resources"};
	}
}
