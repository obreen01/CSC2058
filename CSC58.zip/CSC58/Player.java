import java.util.Map;
import java.util.Scanner;

import java.util.*;

public class Player {

    private final Techopoly game;
    int cursor;
    int balance;
    int playerOrder;
    int getOutOfBSOD;
    boolean BDOS;
    ArrayList<Softwares> softwares = new ArrayList<>();
    ArrayList<Hardwares> hardwares = new ArrayList<>();
    ArrayList<Servers> servers = new ArrayList<>();
    ArrayList<Premise> premise = new ArrayList<>();
    ArrayList<HumanResources> humanResources = new ArrayList<>();


    Scanner s = new Scanner(System.in);
    String[] businessName = new String[8];
    private String name;

    {
        for (int i = 0; i < 8; i++) {
            businessName[i] = s.nextLine();
            System.out.println(businessName[i]); }
    }

    public Player(String n, int b, int p, Techopoly tempTech){
        this.game = tempTech;
        this.name = n;
        this.balance = b;
        this.playerOrder = p;
    }

    public Techopoly getGame() {
        return this.game;
    }
    public String getName(){
        return this.name;
    }
    public void changeName(String s){
        name = s;

    }
    public void addMoney(int amt){
        this.balance = this.balance + amt;

    }

    public int getMoney() {
        //Keep an incrementing count of the players finance
        return this.balance;
    }
    public int takeMoney(int amt){
        int temp;
        if(this.balance > amt){
            temp = this.balance;
            this.balance = 0;
        }
        return amt;
    }

    public void useBSODCard(){
        this.getOutOfBSOD -=1;
    }
    public void addBSODCard(){
        this.getOutOfBSOD += 1;
    }
    public boolean checkBDOS(){
        return BDOS;
    }
    public int getPlayerOrder(){
        return this.playerOrder;
    }
    public int getCursor(){
        return this.cursor;
    }
    public void changeCurSqrWithNoCheck(int p){
        cursor = p;
    }
    public void changeCurSqr(int p){
        cursor = p;
        game.checkSquare(p,this);
    }

    public void addProperty(Hardwares h){
        hardwares.add(h);// add property to the players list of the properties
    }
    public void addProperty(Softwares s){
        softwares.add(s);// add property to the players list of properties
    }
    public void addProperty(Servers se) {
        servers.add(se);// add property to the players list of the properties\
    }
    public void addProperty(Premise pe){
        premise.add(pe);// add property to the players list of the properties
    }
    public void addProperty(HumanResources hr){
        humanResources.add(hr);// add property to the players list of the properties
    }
    public void removeProperty(Hardwares h) {//removes properties
        String name = h.getName();//get properties  name
        int index = 0;//store the index

        for (int i = 0; i < hardwares.size();i++) {
            if (hardwares.get(i).getName().equals(name) == true) {//when the property matches
                i = index;//save the index
            }
        }
        hardwares.remove(index);//remove the property in the index

    }
    public void removeProperty(Softwares s) {//removes properties
        String name = s.getName();//get properties  name
        int index = 0;//store the index

        for (int i = 0; i < softwares.size();i++) {
            if (softwares.get(i).getName().equals(name) == true) {//when the property matches
                i = index;//save the index
            }
        }
        softwares.remove(index);//remove the property in the index

    }
    public void removeProperty(Servers se) {//removes properties
        String name = se.getName();//get properties  name
        int index = 0;//store the index

        for (int i = 0; i < servers.size();i++) {
            if (servers.get(i).getName().equals(name) == true) {//when the property matches
                i = index;//save the index
            }
        }
       servers.remove(index);//remove the property in the index

    }
    public void removeProperty(Premise pe) {//removes properties
        String name = pe.getName();//get properties  name
        int index = 0;//store the index

        for (int i = 0; i < premise.size();i++) {
            if (premise.get(i).getName().equals(name) == true) {//when the property matches
                i = index;//save the index
            }
        }
        premise.remove(index);//remove the property in the index

    }
    public void removeProperty(HumanResources hr) {//removes properties
        String name = hr.getName();//get properties  name
        int index = 0;//store the index

        for (int i = 0; i <humanResources.size();i++) {
            if (humanResources.get(i).getName().equals(name) == true) {//when the property matches
                i = index;//save the index
            }
        }
       humanResources.remove(index);//remove the property in the index

    }
    public int numHardware(){
        return hardwares.size();
    }
    public int numSofware(){
        return softwares.size();
    }
    public int numServers(){
        return servers.size();
    }
    public int numPremise(){
        return premise.size();
    }
    public int numHumanResources(){
        return humanResources.size();
    }
    public void returnAllResources(){
        for (int i= 0; i < hardwares.size();i++){
            System.out.println(hardwares.get(i).getName());
        }
        for (int i= 0; i < softwares.size();i++){
            System.out.println(softwares.get(i).getName());
        }
        for (int i= 0; i < servers.size();i++){
            System.out.println(servers.get(i).getName());
        }
        for (int i= 0; i < premise.size();i++){
            System.out.println(premise.get(i).getName());
        }
        for (int i= 0; i < humanResources.size();i++){
            System.out.println(humanResources.get(i).getName());
        }
    }
    public int getPlayerValue() {
        int total = 0;//holds the total value

        for (int i = 0; i < hardwares.size(); i++) {
            total += hardwares.get(i).getPriceValue();
        }
        for (int i = 0; i < softwares.size(); i++) {
            total += softwares.get(i).getPriceValue();
        }
        for (int i = 0; i < servers.size(); i++) {
            total += servers.get(i).getPriceValue();
        }
        for (int i = 0; i < premise.size(); i++) {
            total += premise.get(i).getPriceValue();
        }
        for (int i = 0; i < humanResources.size(); i++) {
            total += humanResources.get(i).getPriceValue();
        }
        total += this.getMoney();

        return total;
    }
    public boolean equals(Player p) {
        if (p.getPlayerOrder() == this.getPlayerOrder()) {//if the player has the same player order

            return true;

        }else {

            return false;
        }
    }

    //Method check how many players left
    public static boolean endGame(Map<String, Player> totalPlayers) {
        if (totalPlayers.size() > 1) {
            return true;
        }
        return false;
    }
}

