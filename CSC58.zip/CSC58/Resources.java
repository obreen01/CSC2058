
public enum Resources {

	T1("Computers"), T2("Software IDE"), T3("Client Server"), T4("Corporation Tax"), T5("Start-up Office"), 
	T6("Programmer"), T7("Hard Drives"), T8("Community Chest"), T9("Database Server"), T10("Expansion Cards"), 
	T11("Software Architect"), T12("Chance"), T13("Accounting Software"), T14("Small programming group"), T15("Jail"), 
	T16("Mail Server"), T17("Payroll Software"), T18("Open Source Server"), T19("Chance"), T20("Server Farm"), 
	T21("CPUs"), T22("Community Chest"), T23("Proxy Server"), T24("Project Management Software"), T25("Jail"), 
	T26("Optical Disk Drive"), T27("Open Source IDE"), T28("Small Office Building"), T29("Chance"), T30("SSDs"),
	T31("Office Skyscraper"), T32("Project Manager"), T33("FPT Server"), T34("CTO"), T35("International Offices");
	
	private String resource;

	Resources(String resource) {
		this.resource = resource;
	}

	public String getResource() {
		return resource;
	}
}
