
public class Dice {
	
	private int die1;
    private int die2; 
    
    public Dice() {
            // Constructor.  Rolls the dice, so that they initially
            // show some random values.
        roll();  // Call the roll() method to roll the dice.
    }
    
    public static void roll() {
            // Roll the dice by setting each of the die to be
            // a random number between 1 and 6.
        die1 = (int)(Math.random()*6) + 1;
        die2 = (int)(Math.random()*6) + 1;
    }
       
    //getters to obtain the die results.
    public int getDie1() {
       return die1;
    }
    
    public int getDie2() {
       return die2;
    }
    
    public int getTotal() {
          // Return the total showing on the two die.
       return die1 + die2;
    }
    
}
