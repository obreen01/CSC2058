import java.util.Scanner;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class GameBoard {

	
	static Scanner input = new Scanner(System.in);
	
	 public static void main(String[] args) {
		 
		 //Start a new Game and Create players
		 newGame();
		 
		 //Show tile options
		 tile();

	}
		//Use Case 1-- 'Creates Business'
		public static void newGame()
		{	
			
		//Create array of players to hold 8 player objects
		Player[] Players = new Player[8];
		
		//Player enters their player name
			System.out.println("Please enter a name for your business: ");
			String[] businessName = new String[8];
			for (int i = 0; i < businessName.length; i++) {
				
			 //Print out business name of the player
				System.out.println(businessName[i]);
				
				//check: is this name correct check?
				
			//Save business name to array
				businessName[i] = input.nextLine(); 
			//Do validation check on characters
			}
			
			//Start Users on Start Square- get business grant
			System.out.println("You are on the Start Square");
			//Give initial money--business grant
			
			
			//Roll dice
			System.out.println("Roll dice?"
					+ "Press Y for yes, N for no");
			String choice = input.nextLine();
			//if press y
			if (choice.equals("Y")) {
				Dice.roll();
			}
			
	}
			
	//Begin Turn
	//Roll dice and land on tile
	public static void tile() {
		
		String options[] = null;
		String tileName = Tile.tileName;
		
		if (tileName != null && options !=null) {
		
			//display name of tile
			System.out.println(tileName);
			for(int i=0;i<tileName.length();i++) {
				System.out.print("_");
			}
			System.out.println("\n");
			
			// display options of the tile
			// prefix each with an int starting at 1
			int count = 1;
			for(String str : options) {
				System.out.println(count+". "+str);
				count++;
			}
			
			System.out.println(
					//Number and resource of tile= tile name
					"Tile 1: Computers"
					+ "1: Buy"
					+ "2: Sell"
					+ "Display Price from tile class"
					+ "Current Finance"
					+ "Project Completion: "
					+ "3: Exit Game"
			   );
		}
		else {
			// tile and/or options are not valid
			System.out.println("Error");
		}
		
		//Get players choice
					System.out.print("Enter choice: ");
					int choice = input.nextInt();
	
					//Copies Players's Options
					String data[] = new String[6];
						if ( data != null) {
							options = new String[data.length];
							for(int index=0;index<data.length;index++) {
								options[index] = data[index];
							}
						}
						else {
							options = null;
						}	
						
						
	}
	
	
	//Move next tile
	/*
	public Player moveOn(Player playerTemp, int diceNo) {
		Player player = null;
			if (BoardData.totalPlayer.(playerTemp.getName())) {
				player = BoardData..get(playerTemp.getName());
				movePlayerOnTheBoard(player, diceNo);
				if (null != player.getCurrentPosition()) {
						if (Player.isPlayerOnTile(player)) {
							Player.increaseOrDecreaseFinance(player);
						} else {
							int amount = 0;
							if (null != Resource.getOwner()) {
								if (!playerTemp.getName()
										 {
									amount = curResource.getResourceList()
											.get(curResource.getPrice() - 1);
								} else {
									throw new FunctionalException(
											"Player x owns this resource");
								}
							} else {
								amount = curResource.getPrice();
							}
							*/
}

