import java.util.List;

public class Tile {

    public static String tileName;
    private int price;
		private Player playerNo;
		private int currentFinance = 1;
		private double projectCompletion= 0.0;
		private List<Integer> resourcePrice;
		private Tile next;
		private Player businessName;
		private Player ownerOfResource;

	public String getTileName() {
		return tileName;
	}

	public void setTileName(String tileName) {
		this.tileName = tileName;
	}

	public double getProjectCompletion() {
		return projectCompletion;
	}

	public void setProjectCompletion(double projectCompletion) {
		this.projectCompletion = projectCompletion;
	}

	public List<Integer> getResourcePrice() {
		return resourcePrice;
	}

	public void setResourcePrice(List<Integer> resourcePrice) {
		this.resourcePrice = resourcePrice;
	}

	public Player getBusinessName() {
		return businessName;
	}

	public void setBusinessName(Player businessName) {
		this.businessName = businessName;
	}

	public void setOwnerOfResource(Player ownerOfResource) {
		this.ownerOfResource = ownerOfResource;
	}

	public Tile getNext() {
			return next;
		}

		public void setNext(Tile next) {
			this.next = next;
		}

		public int getPrice() {
			return price;
		}

		public void setPrice(int price) {
			this.price = price;
		}

		public Player getPlayerName() {
			return businessName;
		}

		public void setPlayerName(Player name) {
			try
			{
				this.businessName = name;
			}
			catch(IllegalArgumentException e)
			{
				System.out.println("Error! Please check the player has been created correctly!");
			}
		}
		

		public int getCurrentFinance() {
			return currentFinance;
		}

		public void setCurrentFinance(int currentMoney) {
			try
			{
				this.currentFinance = currentMoney;
			}
			catch(IllegalArgumentException e)
			{
				System.out.println("Error! Must be a number!"); // Checking that int has been passed to the method
			}
		}

		public List<Integer> resourcePrice() {
			return resourcePrice;
		}

		public void setPerLevelRentList(List<Integer> resourcePriceList) {
			this.resourcePrice = resourcePriceList;
		}

		public Player getOwnerOfResource() {
			return ownerOfResource;
		}

		public void setOwnerOfProperty(Player ownerOfResource) {
			try
			{
				this.ownerOfResource = ownerOfResource;
			}
			catch(IllegalArgumentException e)
			{
				System.out.println("Error! Please pass through a player!"); // Checking that player has been passed to the method
			}
		}

		public void setTileName(Object allResourceList) {
			// Give each title a resource
			
		}

	public Player getPlayerNo() {
		return playerNo;
	}

	protected void setResource(String resource) {
	}

	protected void options() {
	}

	protected String getName() {
		return null;
	}
}