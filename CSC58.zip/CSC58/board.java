import java.util.*;

public class board extends Tile {
    public static LinkedList<Tile> boardList = null;
    private int size;
    private Tile head;
    public Scanner myScanner = new Scanner(System.in);

    public void append(Tile tile) {
        if (null == tile) {
            return;
        }
        if (null == head) {
            head = tile;
            tile.setNext(tile);
            size++;
            return;
        } else {
            Tile temp = head;
            while (temp.getNext() != head) {
                temp = temp.getNext();
            }
            tile.setNext(temp.getNext());
            temp.setNext(tile);
            size++;
            return;
        }
    }

    public Tile getHead() {
        if (null != head) {
            return head;
        }
        return null;
    }

    public int getSize() {
        return size;
    }


    public static void loadBoardTiles() {
        boardList = new LinkedList<Tile>();
        Tile head = new Tile();
        head.setTileName(Tiles.GO.getValue());

        boardList.add(head);
        Tile Tile1 = new Tile();
        Tile1.setTileName(Tiles.HARDWARE.getValue());
        Tile1.setResource(Resources.T1.getResource());
        Tile1.setPrice(60);
        //calculate the penalty for landing based on how many of some category the owner has
        //calculate the project completion percentage for the user
        //calculate the money lost/ money gained by the user
        boardList.add(Tile1);

        Tile Tile2 = new Tile();
        Tile2.setTileName(Tiles.SOFTWARE.getValue());
        Tile2.setResource(Resources.T2.getResource());
        Tile2.setPrice(60);
        Tile2.options();
        boardList.add(Tile2);

        Tile Tile3 = new Tile();
        Tile3.setTileName(Tiles.SERVERS.getValue());
        Tile3.setResource(Resources.T3.getResource());
        Tile3.setPrice(100);
        Tile3.options();
        boardList.add(Tile3);

        Tile Tile4 = new Tile();
        Tile4.setTileName(Tiles.SPECIAL_TILE.getValue());
        Tile4.setResource(Resources.T4.getResource());
        Tile4.setPrice(100);
        Tile4.options();
        boardList.add(Tile4);

        Tile Tile5 = new Tile();
        Tile5.setTileName(Tiles.PREMISE.getValue());
        Tile5.setResource(Resources.T5.getResource());
        Tile5.setPrice(100);
        Tile5.options();
        boardList.add(Tile5);

        Tile Tile6 = new Tile();
        Tile6.setTileName(Tiles.HUMAN_RESOURCES.getValue());
        Tile6.setResource(Resources.T6.getResource());
        Tile6.setPrice(120);
        Tile6.options();
        boardList.add(Tile2);

        Tile Tile7 = new Tile();
        Tile7.setTileName(Tiles.HARDWARE.getValue());
        Tile7.setResource(Resources.T7.getResource());
        Tile7.setPrice(120);
        Tile7.options();
        boardList.add(Tile7);

        Tile Tile8 = new Tile();
        Tile8.setTileName(Tiles.SPECIAL_TILE.getValue());
        Tile8.setResource(Resources.T8.getResource());
        Tile8.setPrice(100);
        Tile8.options();
        boardList.add(Tile8);

        Tile Tile9 = new Tile();
        Tile9.setTileName(Tiles.SERVERS.getValue());
        Tile9.setResource(Resources.T9.getResource());
        Tile9.setPrice(100);
        Tile9.options();
        boardList.add(Tile9);

        Tile Tile10 = new Tile();
        Tile10.setTileName(Tiles.HARDWARE.getValue());
        Tile10.setResource(Resources.T10.getResource());
        Tile10.setPrice(100);
        Tile10.options();
        boardList.add(Tile10);

        Tile Tile11 = new Tile();
        Tile11.setTileName(Tiles.HUMAN_RESOURCES.getValue());
        Tile11.setResource(Resources.T11.getResource());
        Tile11.setPrice(100);
        Tile11.options();
        boardList.add(Tile11);

        Tile Tile12 = new Tile();
        Tile12.setTileName(Tiles.SPECIAL_TILE.getValue());
        Tile12.setResource(Resources.T12.getResource());
        Tile12.setPrice(100);
        Tile12.options();
        boardList.add(Tile12);

        Tile Tile13 = new Tile();
        Tile13.setTileName(Tiles.SOFTWARE.getValue());
        Tile13.setResource(Resources.T13.getResource());
        Tile13.setPrice(100);
        Tile13.options();
        boardList.add(Tile13);

        Tile Tile14 = new Tile();
        Tile14.setTileName(Tiles.HUMAN_RESOURCES.getValue());
        Tile14.setResource(Resources.T14.getResource());
        Tile14.setPrice(100);
        Tile14.options();
        boardList.add(Tile14);

        Tile Tile15 = new Tile();
        Tile15.setTileName(Tiles.SPECIAL_TILE.getValue());
        Tile15.setResource(Resources.T15.getResource());
        Tile15.setPrice(100);
        Tile15.options();
        boardList.add(Tile15);

        Tile Tile16 = new Tile();
        Tile16.setTileName(Tiles.SERVERS.getValue());
        Tile16.setResource(Resources.T16.getResource());
        Tile16.setPrice(100);
        Tile16.options();
        boardList.add(Tile16);

        Tile Tile17 = new Tile();
        Tile17.setTileName(Tiles.SOFTWARE.getValue());
        Tile17.setResource(Resources.T17.getResource());
        Tile17.setPrice(100);
        Tile17.options();
        boardList.add(Tile17);

        Tile Tile18 = new Tile();
        Tile18.setTileName(Tiles.SERVERS.getValue());
        Tile18.setResource(Resources.T18.getResource());
        Tile18.setPrice(100);
        Tile18.options();
        boardList.add(Tile18);

        Tile Tile19 = new Tile();
        Tile19.setTileName(Tiles.SPECIAL_TILE.getValue());
        Tile19.setResource(Resources.T19.getResource());
        Tile19.setPrice(100);
        Tile19.options();
        boardList.add(Tile19);

        Tile Tile20 = new Tile();
        Tile20.setTileName(Tiles.PREMISE.getValue());
        Tile20.setResource(Resources.T20.getResource());
        Tile20.setPrice(100);
        Tile20.options();
        boardList.add(Tile20);

        Tile Tile21 = new Tile();
        Tile21.setTileName(Tiles.HARDWARE.getValue());
        Tile21.setResource(Resources.T21.getResource());
        Tile21.setPrice(100);
        Tile21.options();
        boardList.add(Tile21);

        Tile Tile22 = new Tile();
        Tile22.setTileName(Tiles.SPECIAL_TILE.getValue());
        Tile22.setResource(Resources.T22.getResource());
        Tile22.setPrice(100);
        Tile22.options();
        boardList.add(Tile22);

        Tile Tile23 = new Tile();
        Tile23.setTileName(Tiles.SERVERS.getValue());
        Tile23.setResource(Resources.T23.getResource());
        Tile23.setPrice(100);
        Tile23.options();
        boardList.add(Tile23);

        Tile Tile24 = new Tile();
        Tile24.setTileName(Tiles.SOFTWARE.getValue());
        Tile24.setResource(Resources.T24.getResource());
        Tile24.setPrice(100);
        Tile24.options();
        boardList.add(Tile24);

        Tile Tile25 = new Tile();
        Tile25.setTileName(Tiles.SPECIAL_TILE.getValue());
        Tile25.setResource(Resources.T25.getResource());
        Tile25.setPrice(100);
        Tile25.options();
        boardList.add(Tile25);

        Tile Tile26 = new Tile();
        Tile26.setTileName(Tiles.HARDWARE.getValue());
        Tile26.setResource(Resources.T26.getResource());
        Tile26.setPrice(100);
        Tile26.options();
        boardList.add(Tile26);

        Tile Tile27 = new Tile();
        Tile27.setTileName(Tiles.SOFTWARE.getValue());
        Tile27.setResource(Resources.T27.getResource());
        Tile27.setPrice(100);
        Tile27.options();
        boardList.add(Tile27);

        Tile Tile28 = new Tile();
        Tile28.setTileName(Tiles.PREMISE.getValue());
        Tile28.setResource(Resources.T28.getResource());
        Tile28.setPrice(100);
        Tile28.options();
        boardList.add(Tile28);

        Tile Tile29 = new Tile();
        Tile29.setTileName(Tiles.SPECIAL_TILE.getValue());
        Tile29.setResource(Resources.T29.getResource());
        Tile29.setPrice(100);
        Tile29.options();
        boardList.add(Tile29);

        Tile Tile30 = new Tile();
        Tile30.setTileName(Tiles.HARDWARE.getValue());
        Tile30.setResource(Resources.T30.getResource());
        Tile30.setPrice(100);
        Tile30.options();
        boardList.add(Tile30);

        Tile Tile31 = new Tile();
        Tile31.setTileName(Tiles.PREMISE.getValue());
        Tile31.setResource(Resources.T31.getResource());
        Tile31.setPrice(100);
        Tile31.options();
        boardList.add(Tile31);

        Tile Tile32 = new Tile();
        Tile32.setTileName(Tiles.HUMAN_RESOURCES.getValue());
        Tile32.setResource(Resources.T32.getResource());
        Tile32.setPrice(100);
        Tile32.options();
        boardList.add(Tile32);

        Tile Tile33 = new Tile();
        Tile33.setTileName(Tiles.SERVERS.getValue());
        Tile33.setResource(Resources.T33.getResource());
        Tile33.setPrice(100);
        Tile33.options();
        boardList.add(Tile33);

        Tile Tile34 = new Tile();
        Tile34.setTileName(Tiles.HUMAN_RESOURCES.getValue());
        Tile34.setResource(Resources.T34.getResource());
        Tile34.setPrice(100);
        Tile34.options();
        boardList.add(Tile34);

        Tile Tile35 = new Tile();
        Tile35.setTileName(Tiles.PREMISE.getValue());
        Tile35.setResource(Resources.T35.getResource());
        Tile35.setPrice(100);
        Tile35.options();
        boardList.add(Tile35);
    }

    public Tile getCurrentTile() {
        int position = 0; // Placeholder
        Tile thisTile = boardList.get(position);
        return thisTile;
    }


    public void options() {

        System.out.println("Tile: " + getCurrentTile().getName() + "\n");
        System.out.println("Cost of Tile: " + getCurrentTile().getPrice() + "\n");

        int ownerCheck = 0;
        int turnFinish = 0;
        String input = "";

        if (getCurrentTile().getOwnerOfResource() != null) // Checks to see if tile already has an owner
        {
            System.out.println("Tile is owned by player " + getCurrentTile().getOwnerOfResource() + "\n");
            ownerCheck = 1;
        }

        while (turnFinish != 1) // Turn will loop until valid input given
        {
            System.out.println("Please select one of the following options:\n");
            if (ownerCheck == 0) {
                System.out.println("A: Purchase tile, B: Do not purchase");
            } else {
                System.out.println("A: Pay penalty of " + getCurrentTile().getPrice() + " to player " + getCurrentTile().getOwnerOfResource() + ", B: Offer trade to player " + getCurrentTile().getOwnerOfResource());
            }

            input = myScanner.nextLine().toUpperCase();

            if (input != "A" && input != "B") {
                System.out.println("Error - invalid input. Please enter A or B to proceed.");
            } else {
                if (input == "A") // Purchase tile or Pay penalty to another player
                {
                    if (ownerCheck == 0) // Purchase tile
                    {
                        // Deduct balance from player
                        // Add resource to player's resource list
                        turnFinish = 1; // Turn ends
                    } else {
                        // Deduct balance from player and add balance to owner
                        turnFinish = 1; // Turn ends
                    }
                } else // Do not purchase or offer trade to fellow player
                {
                    int thisTile = 0;
                    Tile desiredTile = null;
                    if (ownerCheck == 1) // Offering trade
                    {
                        int validCheck = 0;
                        while (validCheck == 0) {
                            System.out.println("Please enter tile number of the resource you wish to trade: ");
                            thisTile = myScanner.nextInt();
                            desiredTile = boardList.get(thisTile);

                            Player player = null;
                            if (getCurrentTile().getOwnerOfResource() == player) // NEED PLAYER
                            {
                                validCheck = 1;
                            } else {
                                System.out.println("Invalid tile entered or you have entered a tile you do not own. Please try again.");
                            }
                        }

                        System.out.println("PLAYER " + getCurrentTile().getOwnerOfResource() + " PLEASE TAKE CONTROL NOW!\n");

                        int yesnoCheck = 0;
                        while (yesnoCheck == 0) {
                            System.out.println("You have been offered " + desiredTile.getName() + ",\nwhich has a value of " + desiredTile.getPrice() + " in exchange for " + getCurrentTile().getName() + ", which has a value of " + getCurrentTile().getPrice() + ".");
                            System.out.println("Do you accept this trade? Y/N");
                            String yesNo = myScanner.nextLine();

                            if (yesNo.toUpperCase() != "Y" && yesNo.toUpperCase() != "N") // If input not Y or N, loop repeats
                            {
                                System.out.println("Please enter Y or N.");
                            } else {
                                if (yesNo.toUpperCase() == "Y") // Processing trade
                                {
                                    turnFinish = 1; // Closing turn loop
                                } else {
                                    System.out.println("ORIGINAL PLAYER PLEASE TAKE CONTROL NOW!\n");
                                    System.out.println("Your trade offer has been declined. Please select an option to proceed."); // Turn loops again, player can offer another trade or pay penalty
                                }
                            }
                        }

                    } else {
                        turnFinish = 1; // No current owner and player chooses not to purchase
                    }
                }


            }


        }
    }
}
