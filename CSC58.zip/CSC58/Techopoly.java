public class Techopoly {
    public void checkSquare(int p, Player player) {
    }
}
