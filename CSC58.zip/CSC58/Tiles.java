
public enum Tiles {
	GO("Go"),SOFTWARE("Software"), HARDWARE("Hardware"), SERVERS("Servers"), PREMISE("Premise"), HUMAN_RESOURCES("Human Resources"),
	SPECIAL_TILE("Special Tile");
	
	private String name;

	private Tiles(String name) {
		this.name = name;
	}

	public String getValue() {
		return name;
	}
}
